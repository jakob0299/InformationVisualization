# Imports of goods and services - Data package

This data package contains the data that powers the chart ["Imports of goods and services"](https://ourworldindata.org/grapher/imports-of-goods-and-services-constant-2010-us?v=1&csvType=full&useColumnShortNames=false) on the Our World in Data website. It was downloaded on November 27, 2025.

### Active Filters

A filtered subset of the full data was downloaded. The following filters were applied:

## CSV Structure

The high level structure of the CSV file is that each row is an observation for an entity (usually a country or region) and a timepoint (usually a year).

The first two columns in the CSV file are "Entity" and "Code". "Entity" is the name of the entity (e.g. "United States"). "Code" is the OWID internal entity code that we use if the entity is a country or region. For normal countries, this is the same as the [iso alpha-3](https://en.wikipedia.org/wiki/ISO_3166-1_alpha-3) code of the entity (e.g. "USA") - for non-standard countries like historical countries these are custom codes.

The third column is either "Year" or "Day". If the data is annual, this is "Year" and contains only the year as an integer. If the column is "Day", the column contains a date string in the form "YYYY-MM-DD".

The final column is the data column, which is the time series that powers the chart. If the CSV data is downloaded using the "full data" option, then the column corresponds to the time series below. If the CSV data is downloaded using the "only selected data visible in the chart" option then the data column is transformed depending on the chart type and thus the association with the time series might not be as straightforward.

## Metadata.json structure

The .metadata.json file contains metadata about the data package. The "charts" key contains information to recreate the chart, like the title, subtitle etc.. The "columns" key contains information about each of the columns in the csv, like the unit, timespan covered, citation for the data etc..

## About the data

Our World in Data is almost never the original producer of the data - almost all of the data we use has been compiled by others. If you want to re-use data, it is your responsibility to ensure that you adhere to the sources' license and to credit them correctly. Please note that a single time series may have more than one source - e.g. when we stich together data from different time periods by different producers or when we calculate per capita metrics using population data from a second source.

## Detailed information about the data


## Imports of goods and services
Last updated: September 8, 2025  
Next update: September 2026  
Date range: 1960–2024  
Unit: constant 2015 US$  


### How to cite this data

#### In-line citation
If you have limited space (e.g. in data visualizations), you can use this abbreviated in-line citation:  
World Bank and OECD national accounts (2025) – processed by Our World in Data

#### Full citation
World Bank and OECD national accounts (2025) – processed by Our World in Data. “Imports of goods and services” [dataset]. World Bank and OECD national accounts, “World Development Indicators 122” [original data].
Source: World Bank and OECD national accounts (2025) – processed by Our World In Data

### How is this data described by its producer - World Bank and OECD national accounts (2025)?
Imports of goods and services represent the value of all goods and other market services received from the rest of the world. They include the value of merchandise, freight, insurance, transport, travel, royalties, license fees, and other services, such as communication, construction, financial, information, business, personal, and government services. They exclude compensation of employees and investment income (formerly called factor services) and transfer payments. Data are in constant 2015 prices, expressed in U.S. dollars.

### Limitations and exceptions:
Because policymakers have tended to focus on fostering the growth of output, and because data on production are easier to collect than data on spending, many countries generate their primary estimate of GDP using the production approach. Moreover, many countries do not estimate all the components of national expenditures but instead derive some of the main aggregates indirectly using GDP (based on the production approach) as the control total.

Data on exports and imports are compiled from customs reports and balance of payments data. Although the data from the payments side provide reasonably reliable records of cross-border transactions, they may not adhere strictly to the appropriate definitions of valuation and timing used in the balance of payments or corresponds to the change-of ownership criterion. This issue has assumed greater significance with the increasing globalization of international business. Neither customs nor balance of payments data usually capture the illegal transactions that occur in many countries. Goods carried by travelers across borders in legal but unreported shuttle trade may further distort trade statistics.

### Statistical concept and methodology:
Gross domestic product (GDP) from the expenditure side is made up of household final consumption expenditure, general government final consumption expenditure, gross capital formation (private and public investment in fixed assets, changes in inventories, and net acquisitions of valuables), and net exports (exports minus imports) of goods and services. Such expenditures are recorded in purchaser prices and include net taxes on products.

### Source

#### World Bank and OECD national accounts – World Development Indicators
Retrieved on: 2025-09-08  
Retrieved from: https://data.worldbank.org/indicator/NE.IMP.GNFS.KD  


    